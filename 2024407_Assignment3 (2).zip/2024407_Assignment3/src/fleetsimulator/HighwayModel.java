package fleetsimulator;

public class HighwayModel {
    private static int highwayDistance = 0;

    public int getTotalDistance() {
        return highwayDistance;
    }

    public void reset() {
        highwayDistance = 0;
    }

    public void distance_add(boolean Lock_mode) {
        // FIX: Changed "=" (assignment) to "==" (comparison)
        if (Lock_mode == true) { 
            synchronized (this) {
                highwayDistance = highwayDistance + 1;
            }
        } else {
            // BUG SIMULATION (Race Condition)
            int distance = highwayDistance;
            
            try {
                // Increase this sleep slightly to force the collision more often
                Thread.sleep(5); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            highwayDistance = distance + 1;
        }
    }
}