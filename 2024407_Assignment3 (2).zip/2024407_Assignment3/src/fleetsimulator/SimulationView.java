package fleetsimulator;

import javax.swing.*;
import java.awt.*;

public class SimulationView extends JFrame {
    
    public JLabel totalDistance_Label;
    public JLabel statusMessage_Label;
    
    public JLabel vehicle1_Label;
    public JLabel vehicle2_Label;
    public JLabel vehicle3_Label;

    public JButton start_Button;
    public JButton pause_Button;
    public JButton resume_Button;
    public JButton stop_Button;
    public JButton refuel_Button;
    
    public JCheckBox syncCheckBox;

    public SimulationView() {
        setTitle("Fleet Highway Simulator");
        setSize(1700, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1)); 


        JPanel topPanel = new JPanel(new GridLayout(2, 1));
        totalDistance_Label = new JLabel("TOTAL DISTANCE: 0 km", SwingConstants.CENTER);
        totalDistance_Label.setFont(new Font("Arial", Font.BOLD, 24));
        
        statusMessage_Label = new JLabel("SYNC OFF", SwingConstants.CENTER);
        statusMessage_Label.setForeground(Color.RED);
        
        topPanel.add(totalDistance_Label);
        topPanel.add(statusMessage_Label);
        add(topPanel);

        JPanel centerPanel = new JPanel(new GridLayout(3, 1));
        vehicle1_Label = new JLabel("Vehicle 1: Ready");
        vehicle2_Label = new JLabel("Vehicle 2: Ready");
        vehicle3_Label = new JLabel("Vehicle 3: Ready");
        
        Font vehicleFont = new Font("Monospaced", Font.BOLD, 16);
        vehicle1_Label.setFont(vehicleFont);
        vehicle2_Label.setFont(vehicleFont);
        vehicle3_Label.setFont(vehicleFont);

        centerPanel.add(vehicle1_Label);
        centerPanel.add(vehicle2_Label);
        centerPanel.add(vehicle3_Label);
        add(centerPanel);

        JPanel buttonPanel = new JPanel();
        start_Button = new JButton("Start");
        pause_Button = new JButton("Pause");
        resume_Button = new JButton("Resume");
        stop_Button = new JButton("Stop");
        refuel_Button = new JButton("Refuel All");
        syncCheckBox = new JCheckBox("Fix Race Condition");

        pause_Button.setEnabled(false);
        resume_Button.setEnabled(false);
        stop_Button.setEnabled(false);

        buttonPanel.add(start_Button);
        buttonPanel.add(pause_Button);
        buttonPanel.add(resume_Button);
        buttonPanel.add(stop_Button);
        buttonPanel.add(refuel_Button);
        buttonPanel.add(syncCheckBox);
        add(buttonPanel);
    }
}