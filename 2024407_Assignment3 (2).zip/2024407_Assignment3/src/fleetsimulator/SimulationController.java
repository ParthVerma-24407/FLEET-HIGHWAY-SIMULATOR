package fleetsimulator;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.Timer;

public class SimulationController {
    private SimulationView view;
    private HighwayModel model;
    
    private ArrayList<Vehicle> vehicles = new ArrayList<>();
    
    private Object pauseLock = new Object();
    
    private Timer Timer;

    public SimulationController(SimulationView view, HighwayModel model) {
        this.view = view;
        this.model = model;

        
        view.start_Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                startSimulation();
            }
        });

        view.pause_Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pauseSimulation();
            }
        });

        view.resume_Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resumeSimulation();
            }
        });

        view.stop_Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                stopSimulation();
            }
        });

        view.refuel_Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                for (Vehicle v : vehicles) {
                    v.fuel_addition(20);
                }
            }
        });

        view.syncCheckBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (view.syncCheckBox.isSelected()) {
                    view.statusMessage_Label.setText("Sync ON.");
                    view.statusMessage_Label.setForeground(new Color(0, 150, 0)); // Green
                } 
                else {
                    view.statusMessage_Label.setText("Sync OFF.");
                    view.statusMessage_Label.setForeground(Color.RED);
                }
            }
        });

        Timer = new Timer(50, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUI();
            }
        });
    }


    private void startSimulation() {
        model.reset();
        vehicles.clear();
        
        vehicles.add(new Vehicle("Vehicle 1", 20, pauseLock, this));
        vehicles.add(new Vehicle("Vehicle 2", 20, pauseLock, this));
        vehicles.add(new Vehicle("Vehicle 3", 20, pauseLock, this));

        for (Vehicle v : vehicles) {
            Thread t = new Thread(v);
            t.start();
        }

        Timer.start();

        view.start_Button.setEnabled(false);
        view.pause_Button.setEnabled(true);
        view.stop_Button.setEnabled(true);
    }

    private void pauseSimulation() {
        for (Vehicle v : vehicles) {
            v.paused(true);
        }
        view.pause_Button.setEnabled(false);
        view.resume_Button.setEnabled(true);
    }

    private void resumeSimulation() {
        for (Vehicle v : vehicles) {
            v.paused(false);
        }
        
        synchronized (pauseLock) {
            pauseLock.notifyAll();
        }

        view.pause_Button.setEnabled(true);
        view.resume_Button.setEnabled(false);
    }

    private void stopSimulation() {
        for (Vehicle v : vehicles) {
            v.stop_vehicle();
        }
        synchronized (pauseLock) {
            pauseLock.notifyAll();
        }
        
        Timer.stop();
        
        view.start_Button.setEnabled(true);
        view.pause_Button.setEnabled(false);
        view.resume_Button.setEnabled(false);
        view.stop_Button.setEnabled(false);
    }

    public void updateSharedCounter() {
        boolean is_ok = view.syncCheckBox.isSelected();
        model.distance_add(is_ok);
    }

    private void GUI() {
        view.totalDistance_Label.setText("Total Distance: " + model.getTotalDistance() + " km");
        int size = vehicles.size();
        if (size >= 3) {
            view.vehicle1_Label.setText(formatVehicleString(vehicles.get(0)));
            view.vehicle2_Label.setText(formatVehicleString(vehicles.get(1)));
            view.vehicle3_Label.setText(formatVehicleString(vehicles.get(2)));
        }
    }

    private String formatVehicleString(Vehicle v) {
    return "VEHICLE_ID: " + v.getId() + " -> Fuel: " + v.getFuel() + 
           " -> Distance: " + v.getMileage() + "km -> " + v.getStatus();
}
}