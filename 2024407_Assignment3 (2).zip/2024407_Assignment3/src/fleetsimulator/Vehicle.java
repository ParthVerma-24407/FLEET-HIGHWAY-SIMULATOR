package fleetsimulator;

public class Vehicle implements Runnable {
    private String vehicle_id;
    private int fuel_amount;
    private int mileage;
    
    
    private boolean stopRequested = false; 
    private Object lock; 
    private boolean paused = false;

    
    private SimulationController handler;

    public Vehicle(String vehicle_id, int fuel_amount, Object lock, SimulationController handler) {
        this.vehicle_id = vehicle_id;
        this.fuel_amount = fuel_amount;
        this.lock = lock;
        this.handler = handler;
        this.mileage = 0;
    }


    public void stop_vehicle() {
        this.stopRequested = true;
    }
    public void fuel_addition(int amount) {
        this.fuel_amount = this.fuel_amount + amount;
    }

 
    public void paused(boolean paused) {
        this.paused = paused;
    }

    @Override
    public void run() {
        while (stopRequested == false) {
            try {
                synchronized (lock) {
                    while (paused) {
                        lock.wait(); 
                    }
                }

                Thread.sleep(1000); 

                if (fuel_amount > 0) {
                    fuel_amount=fuel_amount-1;      
                    mileage=mileage+1;   
                    
                    handler.updateSharedCounter(); 
                } 

            } catch (InterruptedException e) {
                stopRequested = true;
            }
        }
    }
    

    public String getId() { 
        return vehicle_id; 
    }
    public int getFuel() {
         return fuel_amount; 
    }
    public int getMileage() {
         return mileage;
    }
    
    public String getStatus() {
        if (stopRequested) {
            return "Stopped";
        }
        if (paused) {
            return "Paused";
        }
        if (fuel_amount <= 0) {
            return "Out-of-Fuel";
        }
        return "Running on Highway";
    }
}