package fleetsimulator;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                HighwayModel model = new HighwayModel();
                SimulationView view = new SimulationView();
                
                new SimulationController(view, model);

                view.setVisible(true);
            }
        });
    }
}